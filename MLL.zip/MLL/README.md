# Credit Card Fraud Detection

This project implements a machine learning pipeline for detecting fraudulent credit card transactions using various classification algorithms. The system is designed to handle highly imbalanced datasets commonly found in fraud detection scenarios.

## Project Structure

```
ML Project/
├── data/
│   └── fraud_7k_14p28.csv
├── models/
│   ├── best_fraud_model.pkl
│   └── robust_scaler.pkl
├── reports/
│   ├── figures/
│   │   └── confusion_matrix.png
│   └── model_metrics.csv
├── fraud_detection.py
├── requirements.txt
└── README.md
```

## Features

- Data preprocessing and feature engineering
- Handling of class imbalance using SMOTE
- Multiple model training and evaluation
- Model persistence and prediction API
- Comprehensive metrics and visualizations

## Prerequisites

- Python 3.8+
- Required Python packages (see `requirements.txt`)

## Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd credit-card-fraud-detection
   ```

2. Create and activate a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install the required packages:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

1. Place your dataset (`fraud_7k_14p28.csv`) in the project root directory.

2. Run the main script:
   ```bash
   python fraud_detection.py
   ```

3. The script will:
   - Load and preprocess the data
   - Train multiple machine learning models
   - Evaluate and compare model performance
   - Save the best model and scaler to the `models` directory
   - Generate reports and visualizations in the `reports` directory

## Making Predictions

You can use the trained model to make predictions on new transactions using the `predict_transaction` function:

```python
from fraud_detection import predict_transaction

# Example transaction features: [step, amount, oldbalanceOrg, newbalanceOrig, oldbalanceDest, newbalanceDest]
sample_transaction = [1, 1000.0, 10000.0, 9000.0, 5000.0, 6000.0]
prediction = predict_transaction(sample_transaction)

print(f"Is Fraud: {prediction['is_fraud']}")
print(f"Fraud Probability: {prediction['fraud_probability']:.4f}")
```

## Model Evaluation

The system evaluates models based on the following metrics:
- Accuracy
- Precision
- Recall
- F1-Score

Confusion matrices are generated for visual evaluation of model performance.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
