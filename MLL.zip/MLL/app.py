import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import os
import numpy as np
from typing import Dict, Any, Optional

# Set page config
st.set_page_config(page_title="Credit Card Fraud Detection", layout="wide")

# Load model metrics
@st.cache_data
def load_metrics():
    metrics_path = "reports/model_metrics.csv"
    if os.path.exists(metrics_path):
        return pd.read_csv(metrics_path)
    return None

# Load model and scaler
@st.cache_resource
def load_model_and_scaler():
    model_path = "models/best_fraud_model.pkl"
    scaler_path = "models/robust_scaler.pkl"
    
    if os.path.exists(model_path) and os.path.exists(scaler_path):
        return joblib.load(model_path), joblib.load(scaler_path)
    return None, None

def adjust_fraud_probability(prob: float, transaction_data: Dict[str, Any]) -> float:
    """
    Adjust fraud probability based on contextual rules.
    
    Args:
        prob: Initial probability from the model (0-1)
        transaction_data: Dictionary containing transaction details
        
    Returns:
        Adjusted probability (0-1)
    """
    amount = float(transaction_data.get('amount', 0))
    old_balance = float(transaction_data.get('oldbalanceOrg', 1))  # Avoid division by zero
    trans_type = str(transaction_data.get('type', '')).upper()
    
    # Calculate balance ratio
    balance_ratio = amount / old_balance if old_balance > 0 else 1.0
    
    # Apply adjustments
    if balance_ratio > 0.8:  # If transaction > 80% of balance
        prob = min(1.0, prob * 1.2)
    elif balance_ratio < 0.1:  # Small transaction
        prob = max(0.0, prob * 0.8)
    
    # Adjust based on transaction type
    if trans_type in ['TRANSFER', 'CASH_OUT']:
        prob = min(1.0, prob * 1.1)
    
    return min(0.99, max(0.01, prob))  # Keep within 1-99% range

def get_risk_level(probability: float) -> tuple:
    """Get risk level and color based on probability."""
    if probability >= 0.7:
        return " HIGH RISK", "#FF6B6B"  # Red
    elif probability >= 0.5:
        return " MEDIUM RISK", "#FFD166"  # Orange
    elif probability >= 0.3:
        return " LOW RISK", "#FFEEAD"  # Yellow
    else:
        return " VERY LOW RISK", "#A8E6CF"  # Green

def get_decision_factors(transaction_data: Dict[str, Any]) -> Dict[str, bool]:
    """Get factors contributing to fraud decision."""
    amount = float(transaction_data.get('amount', 0))
    old_balance = float(transaction_data.get('oldbalanceOrg', 1))
    new_balance = float(transaction_data.get('newbalanceOrig', 0))
    trans_type = str(transaction_data.get('type', '')).upper()
    
    balance_ratio = amount / old_balance if old_balance > 0 else 1.0
    
    return {
        'High transaction amount': amount > 10000,
        'Large portion of balance': balance_ratio > 0.5,
        'Account nearly empty': new_balance / old_balance < 0.2 if old_balance > 0 else False,
        'High-risk transaction type': trans_type in ['TRANSFER', 'CASH_OUT'],
        'Round number amount': amount % 1000 == 0 and amount > 0,
        'New recipient': True  # In a real system, you'd check recipient history
    }

def calculate_fraud_probability(details):
    """Calculate fraud probability based on transaction patterns."""
    fraud_score = 0.0
    
    # Get values from details
    amount = details.get('amount', 0)
    expected_orig = details.get('expected_new_balance_orig', 0)
    provided_orig = details.get('provided_new_balance_orig', 0)
    expected_dest = details.get('expected_new_balance_dest', 0)
    provided_dest = details.get('provided_new_balance_dest', 0)
    
    # Calculate differences
    orig_diff = abs(expected_orig - provided_orig)
    dest_diff = abs(expected_dest - provided_dest)
    
    # 1. Check for zero balance after transaction (high risk)
    if provided_orig == 0 and expected_orig != 0:
        fraud_score += 0.4
    
    # 2. Check if destination balance doesn't match expected (medium risk)
    if dest_diff > amount * 0.1:  # More than 10% of amount is suspicious
        fraud_score += 0.3
    
    # 3. Check for large amounts (over $10,000)
    if amount > 10000:
        fraud_score += 0.2
    
    # 4. Check for round numbers (suspicious for large amounts)
    if amount % 1000 == 0 and amount >= 1000:
        fraud_score += 0.1
    
    # 5. Check if money seems to disappear (very high risk)
    if (expected_orig - provided_orig) > (provided_dest - expected_dest + amount):
        fraud_score += 0.4
    
    # Cap the score at 0.95 (always some uncertainty)
    return min(0.95, fraud_score)

def predict_transaction(model, scaler, transaction_data):
    """Predict if a transaction is fraudulent with validation."""
    try:
        # Ensure transaction_data is a list
        if isinstance(transaction_data, str):
            try:
                # Try to parse the string as a list
                import ast
                transaction_data = ast.literal_eval(transaction_data)
            except (ValueError, SyntaxError):
                return {
                    'is_valid': False,
                    'error': 'Invalid input format. Expected a list of values.',
                    'details': {'input_data': str(transaction_data)[:100]}
                }
        
        # Unpack transaction data
        try:
            step, amount, old_balance_org, new_balance_orig, old_balance_dest, new_balance_dest, trans_type = transaction_data
        except (ValueError, TypeError) as e:
            return {
                'is_valid': False,
                'error': f'Incorrect number of values in input. Expected 7 values.',
                'details': {
                    'input_length': len(transaction_data) if hasattr(transaction_data, '__len__') else 'N/A',
                    'input_data': str(transaction_data)[:100]
                }
            }
        
        # Convert all to float for consistent comparison
        amount = float(amount)
        old_balance_org = float(old_balance_org)
        new_balance_orig = float(new_balance_orig)
        old_balance_dest = float(old_balance_dest)
        new_balance_dest = float(new_balance_dest)
        
        # Validate transaction amount
        if amount <= 0:
            return {
                'is_valid': False,
                'error': 'Transaction amount must be positive',
                'details': {'amount': amount}
            }
            
        # Calculate expected balances (ensure they don't go below zero)
        expected_new_balance_orig = max(0, old_balance_org - amount)
        expected_new_balance_dest = old_balance_dest + amount
        
        # Check for balance consistency (allowing for small floating point discrepancies)
        balance_tolerance = 0.01
        orig_balance_mismatch = abs(new_balance_orig - expected_new_balance_orig) > balance_tolerance
        dest_balance_mismatch = abs(new_balance_dest - expected_new_balance_dest) > balance_tolerance
        
        if orig_balance_mismatch or dest_balance_mismatch:
            details = {
                'expected_new_balance_orig': round(expected_new_balance_orig, 2),
                'provided_new_balance_orig': round(new_balance_orig, 2),
                'expected_new_balance_dest': round(expected_new_balance_dest, 2),
                'provided_new_balance_dest': round(new_balance_dest, 2),
                'amount': round(amount, 2)
            }
            
            # Calculate fraud probability for the mismatch
            fraud_probability = calculate_fraud_probability(details)
            
            return {
                'is_valid': False,
                'error': 'Balance mismatch detected',
                'details': details,
                'fraud_probability': fraud_probability
            }
        
        # Check for negative balances in input fields
        if any(x < 0 for x in [old_balance_org, new_balance_orig, old_balance_dest, new_balance_dest, amount]):
            # Find which fields are negative
            negative_fields = []
            if old_balance_org < 0: negative_fields.append('Old Balance Origin')
            if new_balance_orig < 0: negative_fields.append('New Balance Origin')
            if old_balance_dest < 0: negative_fields.append('Old Balance Destination')
            if new_balance_dest < 0: negative_fields.append('New Balance Destination')
            if amount < 0: negative_fields.append('Amount')
            
            return {
                'is_valid': False,
                'error': f"Negative values are not allowed in: {', '.join(negative_fields)}",
                'details': {
                    'old_balance_org': old_balance_org,
                    'new_balance_orig': new_balance_orig,
                    'old_balance_dest': old_balance_dest,
                    'new_balance_dest': new_balance_dest,
                    'amount': amount
                }
            }
        
        # Check step range (assuming 1-744 represents hours in a month)
        if not (1 <= step <= 744):
            return {
                'is_valid': False,
                'error': 'Invalid step value',
                'details': {
                    'step': step,
                    'valid_range': '1-744 (hours in a month)'
                }
            }
        
        # If all validations pass, prepare data for prediction
        try:
            # Use the exact feature names that the scaler was trained with
            # These must match the order and names exactly
            expected_columns = [
                'step', 'amount', 'oldbalanceOrg', 'newbalanceOrig',
                'oldbalanceDest', 'newbalanceDest',
                'type_CASH_OUT', 'type_DEBIT', 'type_PAYMENT', 'type_TRANSFER'
            ]
            # Note: 'type_CASH_IN' is not in the scaler's features, so we'll map it to all zeros
            
            # Create a new DataFrame with the expected columns, initialized to 0
            transaction_data = {col: [0] for col in expected_columns}
            
            # Map our input data to the expected column names
            # These mappings ensure we're using the exact column names the model expects
            column_mapping = {
                'step': 'step',
                'amount': 'amount',
                'old_balance_org': 'oldbalanceOrg',
                'new_balance_orig': 'newbalanceOrig',
                'old_balance_dest': 'oldbalanceDest',
                'new_balance_dest': 'newbalanceDest'
            }
            
            # Set the values for our known features using the mapping
            for src_col, dest_col in column_mapping.items():
                if dest_col in transaction_data:
                    transaction_data[dest_col] = [locals().get(src_col, 0)]
            
            # Handle transaction type - map to the exact column names the scaler expects
            trans_type_upper = str(trans_type).upper()
            
            # Map transaction types to the expected column names
            trans_type_mapping = {
                'CASH_OUT': 'type_CASH_OUT',
                'DEBIT': 'type_DEBIT',
                'PAYMENT': 'type_PAYMENT',
                'TRANSFER': 'type_TRANSFER'
            }
            
            # Set the appropriate transaction type column to 1 if it exists in our mapping
            trans_type_col = trans_type_mapping.get(trans_type_upper)
            if trans_type_col and trans_type_col in transaction_data:
                transaction_data[trans_type_col] = [1]
            # Note: 'CASH_IN' is not in the scaler's features, so we'll leave all type columns as 0
            
            # Create the final DataFrame with the exact column order
            transaction_df = pd.DataFrame(transaction_data, columns=expected_columns)
            
            # Debug: Print the transaction data being sent for prediction
            print("Transaction data for prediction:")
            print(transaction_df[expected_columns])
            
            # Scale the data
            scaled_data = scaler.transform(transaction_df[expected_columns])
            
        except Exception as e:
            return {
                'is_valid': False,
                'error': f'Error preparing data for prediction: {str(e)}',
                'details': {
                    'step': step,
                    'amount': amount,
                    'old_balance_org': old_balance_org,
                    'new_balance_orig': new_balance_orig,
                    'old_balance_dest': old_balance_dest,
                    'new_balance_dest': new_balance_dest,
                    'trans_type': trans_type
                }
            }
        prediction = model.predict(scaled_data)
        proba = model.predict_proba(scaled_data) if hasattr(model, 'predict_proba') else None
        
        return {
            'is_valid': True,
            'is_fraud': bool(prediction[0]),
            'fraud_probability': float(proba[0][1]) if proba is not None else None,
            'details': {
                'amount': round(amount, 2),
                'old_balance_org': round(old_balance_org, 2),
                'new_balance_orig': round(new_balance_orig, 2),
                'old_balance_dest': round(old_balance_dest, 2),
                'new_balance_dest': round(new_balance_dest, 2)
            }
        }
        
    except Exception as e:
        return {
            'is_valid': False,
            'error': f'Error processing transaction: {str(e)}',
            'details': {'input_data': str(transaction_data)}
        }

# Main app
def main():
    st.title("Credit Card Fraud Detection Dashboard")
    
    # Load data and models
    metrics_df = load_metrics()
    model, scaler = load_model_and_scaler()
    
    # Sidebar for navigation
    page = st.sidebar.radio("Navigation", ["Model Performance", "Make Predictions"])
    
    if page == "Model Performance":
        st.header("Model Performance Metrics")
        
        if metrics_df is not None:
            # Display metrics table
            st.subheader("Performance Comparison")
            st.dataframe(metrics_df.style.format({
                'Accuracy': '{:.2%}',
                'Precision': '{:.2%}',
                'Recall': '{:.2%}',
                'F1-Score': '{:.2%}'
            }))
            
            # Create visualizations
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Accuracy Comparison")
                fig, ax = plt.subplots()
                sns.barplot(x='Model', y='Accuracy', data=metrics_df, ax=ax)
                plt.xticks(rotation=45)
                plt.ylim(0.8, 1.0)
                st.pyplot(fig)
            
            with col2:
                st.subheader("Precision-Recall")
                fig, ax = plt.subplots()
                metrics_df.plot(x='Model', y=['Precision', 'Recall'], kind='bar', ax=ax)
                plt.xticks(rotation=45)
                plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
                st.pyplot(fig)
        else:
            st.warning("Could not load model metrics. Please run the training script first.")
    
    elif page == "Make Predictions":
        st.header("Make Predictions using Random Forest Model")
        
        if model is None or scaler is None:
            st.error("Could not load the model or scaler. Please make sure they exist in the models/ directory.")
            return
            
        st.subheader("Enter Transaction Details")
        
        # Create input fields
        col1, col2 = st.columns(2)
        
        with col1:
            step = st.number_input("Step (1-744)", min_value=1, max_value=744, value=100)
            amount = st.number_input("Amount", min_value=0.0, value=1000.0, step=100.0)
            oldbalance_org = st.number_input("Old Balance Origin", min_value=0.0, value=5000.0, step=100.0)
            trans_type = st.selectbox(
                "Transaction Type",
                options=["CASH_IN", "CASH_OUT", "DEBIT", "PAYMENT", "TRANSFER"],
                index=4  # Default to TRANSFER as it's often highest risk
            )
        
        with col2:
            newbalance_orig = st.number_input("New Balance Origin", min_value=0.0, value=4000.0, step=100.0)
            oldbalance_dest = st.number_input("Old Balance Destination", min_value=0.0, value=2000.0, step=100.0)
            newbalance_dest = st.number_input("New Balance Destination", min_value=0.0, value=3000.0, step=100.0)
        
        # Make prediction
        if st.button("Predict"):
            with st.spinner('Processing transaction...'):
                transaction = [step, amount, oldbalance_org, newbalance_orig, oldbalance_dest, newbalance_dest, trans_type]
                result = predict_transaction(model, scaler, transaction)
                
                st.subheader("Transaction Analysis")
                
                if not result.get('is_valid', False):
                    # Display validation error
                    st.error(f"❌ {result.get('error', 'Invalid transaction')}")
                    
                    # Show detailed error information if available
                    if 'details' in result:
                        st.warning("Transaction Details:")
                        st.json(result['details'])
                        
                        # Special handling for balance mismatch
                        if result.get('error') == 'Balance mismatch detected':
                            details = result['details']
                            from_diff = details['expected_new_balance_orig'] - details['provided_new_balance_orig']
                            to_diff = details['expected_new_balance_dest'] - details['provided_new_balance_dest']
                            
                            error_msg = f"""
                            **Balance Mismatch Detected**
                            
                            - **From Account:**
                              - Expected New Balance: ${details['expected_new_balance_orig']:,.2f}
                              - Provided New Balance: ${details['provided_new_balance_orig']:,.2f}
                              - Difference: ${abs(from_diff):,.2f} ({"less" if from_diff > 0 else "more"} than expected)
                              
                            - **To Account:**
                              - Expected New Balance: ${details['expected_new_balance_dest']:,.2f}
                              - Provided New Balance: ${details['provided_new_balance_dest']:,.2f}
                              - Difference: ${abs(to_diff):,.2f} ({"less" if to_diff > 0 else "more"} than expected)
                              
                            **This transaction has inconsistent balances and should be reviewed.**
                            """
                            st.error(error_msg)
                            
                            # Display fraud probability for the mismatch
                            fraud_prob = result.get('fraud_probability', 0)
                            
                            # Determine risk level
                            if fraud_prob > 0.7:
                                risk_level = "🔴 **HIGH RISK**"
                                risk_color = "red"
                            elif fraud_prob > 0.4:
                                risk_level = "🟠 **MEDIUM RISK**"
                                risk_color = "orange"
                            else:
                                risk_level = "🟡 **LOW RISK**"
                                risk_color = "#FFD700"  # Gold color
                            


                            
                            # Alternative display using st.markdown with proper markdown formatting
                            st.markdown("---")
                            st.markdown(f"### 🚨 Fraud Probability: {fraud_prob:.0%} - {risk_level}")
                            
                            st.markdown("#### Transaction Analysis:")
                            st.markdown(f"- Source account balance {'✅ matches' if abs(from_diff) <= 0.01 else '❌ does not match'} expected (Δ ${abs(from_diff):,.2f})")
                            st.markdown(f"- Destination account balance {'✅ matches' if abs(to_diff) <= 0.01 else '❌ does not match'} expected (Δ ${abs(to_diff):,.2f})")
                            st.markdown(f"- Transaction amount: ${details['amount']:,.2f}")
                            
                            st.markdown("#### Potential Issues:")
                            st.markdown("- Data entry error")
                            st.markdown("- Attempted fraud")
                            st.markdown("- System miscalculation")
                            
                            st.markdown("#### Recommended Actions:")
                            st.markdown("1. Verify transaction details with the account holder")
                            st.markdown("2. Review recent account activity")
                            st.markdown("3. Check for similar suspicious patterns")
                            st.markdown("4. Escalate if multiple red flags are present")
                            
                            # Add a warning for high-risk transactions
                            if fraud_prob > 0.7:
                                st.error("""
                                ⚠️ **IMMEDIATE ACTION REQUIRED**
                                
                                This transaction shows multiple signs of potential fraud. Please:
                                1. Place the transaction on hold
                                2. Contact the account holder immediately
                                3. Review recent account activity
                                4. Escalate to the fraud prevention team
                                """)
                    return
                
                # If we get here, the transaction is valid
                st.success("✅ Transaction data is valid")
                
                # Set a higher threshold for fraud classification
                FRAUD_THRESHOLD = 0.65  # Increased from 0.5 to reduce false positives
                
                # Adjust the probability based on contextual factors
                adjusted_prob = adjust_fraud_probability(
                    result['fraud_probability'],
                    {
                        'amount': amount,
                        'oldbalanceOrg': oldbalance_org,
                        'newbalanceOrig': newbalance_orig,
                        'type': trans_type
                    }
                )
                
                # Make final decision
                is_fraud = adjusted_prob >= FRAUD_THRESHOLD
                risk_level, risk_color = get_risk_level(adjusted_prob)
                
                # Get decision factors
                factors = get_decision_factors({
                    'amount': amount,
                    'oldbalanceOrg': oldbalance_org,
                    'newbalanceOrig': newbalance_orig,
                    'type': trans_type
                })
                
                # Display results with enhanced UI
                st.markdown("---")
                
                # Risk level indicator
                st.markdown(
                    f"<h2 style='text-align: center; color: {risk_color};'>{risk_level}</h2>",
                    unsafe_allow_html=True
                )
                
                # Main metrics
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Transaction Status", 
                             "FRAUD" if is_fraud else "LEGITIMATE",
                             delta=None,
                             delta_color="inverse")
                
                with col2:
                    st.metric("Fraud Probability", 
                             f"{adjusted_prob:.2%}",
                             delta=None)
                    
                with col3:
                    st.metric("Confidence",
                            "High" if abs(adjusted_prob - 0.5) > 0.3 else "Medium",
                            delta=None)
                
                # Transaction summary
                with st.expander("📊 Transaction Summary", expanded=True):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.metric("Amount", f"${amount:,.2f}")
                        st.metric("Old Balance", f"${oldbalance_org:,.2f}")
                        st.metric("New Balance", f"${newbalance_orig:,.2f}")
                    
                    with col2:
                        st.metric("Transaction Type", trans_type)
                        balance_change = (amount / oldbalance_org) * 100 if oldbalance_org > 0 else 0
                        st.metric("Balance Change", f"{balance_change:.1f}%")
                        remaining_balance = (newbalance_orig / oldbalance_org) * 100 if oldbalance_org > 0 else 0
                        st.metric("Remaining Balance", f"{remaining_balance:.1f}%")
                
                # Risk factors
                with st.expander("🔍 Key Risk Factors", expanded=True):
                    for factor, is_present in factors.items():
                        if is_present:
                            st.markdown(f"- ❗ {factor}")
                        else:
                            st.markdown(f"- ✓ {factor} (No significant risk)")
                
                # Recommendations
                with st.expander("📝 Recommendations", expanded=is_fraud):
                    if is_fraud:
                        st.error("""
                        🚨 **Immediate Action Recommended**
                        
                        1. Place transaction on hold
                        2. Verify with account holder
                        3. Check for similar recent transactions
                        4. Escalate to fraud department if needed
                        """)
                    else:
                        st.success("""
                        ✅ **No Immediate Action Required**
                        
                        This transaction appears to be low risk. Continue monitoring
                        for any unusual patterns.
                        """)
                
                # Removed feedback section as requested
                
                # Show feature importance if available
                if hasattr(model, 'feature_importances_'):
                    st.subheader("Feature Importance")
                    
                    # Get the correct feature names in the right order
                    if hasattr(model, 'feature_names_in_'):
                        features = list(model.feature_names_in_)
                    else:
                        # Fallback to our expected columns without the type_ prefix
                        features = [
                            'step', 'amount', 'oldbalanceOrg', 'newbalanceOrig',
                            'oldbalanceDest', 'newbalanceDest',
                            'type_CASH_OUT', 'type_DEBIT', 'type_PAYMENT', 'type_TRANSFER'
                        ]
                    
                    # Ensure we only take as many importances as we have features
                    n_features = len(features)
                    importances = model.feature_importances_
                    
                    # If we have more importances than features, take the first n_features
                    if len(importances) > n_features:
                        importances = importances[:n_features]
                    # If we have fewer importances than features, pad with zeros
                    elif len(importances) < n_features:
                        importances = np.pad(importances, (0, n_features - len(importances)))
                    
                    # Create the importance DataFrame
                    importance = pd.DataFrame({
                        'Feature': features,
                        'Importance': importances
                    }).sort_values('Importance', ascending=False)
                    
                    # Plot the top 10 most important features
                    fig, ax = plt.subplots(figsize=(10, 6))
                    sns.barplot(
                        x='Importance',
                        y='Feature',
                        data=importance.head(10),  # Show top 10 features
                        ax=ax,
                        palette='viridis'
                    )
                    plt.title('Top 10 Most Important Features')
                    plt.tight_layout()
                    st.pyplot(fig)
                    
                    # Show the full feature importance table
                    with st.expander("View All Feature Importances"):
                        st.dataframe(importance.style.format({'Importance': '{:.4f}'}))

if __name__ == "__main__":
    main()
