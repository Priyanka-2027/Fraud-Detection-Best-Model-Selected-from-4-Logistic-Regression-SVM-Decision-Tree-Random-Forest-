import os
import sys
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import RobustScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, ConfusionMatrixDisplay
)
from imblearn.over_sampling import SMOTE
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC

# Set random seed for reproducibility
RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)

# Configuration
CONFIG = {
    'data': {
        'input_file': 'fraud_7k_14p28.csv',
        'test_size': 0.2,
        'drop_columns': ['nameOrig', 'nameDest', 'isFlaggedFraud'],  # Keep 'type' for one-hot encoding
        'target_column': 'isFraud'
    },
    'models': {
        'LogisticRegression': {
            'class_weight': 'balanced',
            'max_iter': 1000,
            'random_state': RANDOM_STATE
        },
        'DecisionTree': {
            'random_state': RANDOM_STATE
        },
        'RandomForest': {
            'n_estimators': 100,
            'class_weight': 'balanced',
            'random_state': RANDOM_STATE
        },
        'SVM': {
            'class_weight': 'balanced',
            'random_state': RANDOM_STATE,
            'dual': False,
            'max_iter': 10000
        }
    },
    'paths': {
        'models': 'models',
        'reports': 'reports',
        'figures': 'reports/figures'
    }
}

def setup_directories():
    """Create necessary directories if they don't exist."""
    for path in CONFIG['paths'].values():
        Path(path).mkdir(parents=True, exist_ok=True)

def load_data(file_path):
    """Load and preprocess the dataset."""
    print(f"\nLoading data from {file_path}...")
    try:
        df = pd.read_csv(file_path)
        print(f"Original dataset shape: {df.shape}")
        return df
    except Exception as e:
        print(f"Error loading data: {str(e)}")
        sys.exit(1)

def preprocess_data(df):
    """Preprocess the dataset."""
    print("\nPreprocessing data...")
    
    # Make a copy to avoid modifying the original dataframe
    df = df.copy()
    
    # One-hot encode the 'type' column
    if 'type' in df.columns:
        df = pd.get_dummies(df, columns=['type'], prefix='type', drop_first=True)
        print("Applied one-hot encoding to 'type' column")
    
    # Drop specified columns
    df = df.drop(columns=CONFIG['data']['drop_columns'], errors='ignore')
    
    # Check for missing values
    missing = df.isnull().sum()
    if missing.any():
        print("\nMissing values found:")
        print(missing[missing > 0])
        # Handle missing values if any
        df = df.fillna(method='ffill')
    
    # Ensure all expected type columns exist
    expected_type_columns = ['type_CASH_OUT', 'type_DEBIT', 'type_PAYMENT', 'type_TRANSFER']
    for col in expected_type_columns:
        if col not in df.columns and col != CONFIG['data']['target_column']:
            df[col] = 0
    
    print(f"Processed dataset shape: {df.shape}")
    print("Columns after preprocessing:", df.columns.tolist())
    
    return df

def split_data(X, y):
    """Split data into training and testing sets."""
    return train_test_split(
        X, y,
        test_size=CONFIG['data']['test_size'],
        random_state=RANDOM_STATE,
        stratify=y
    )

def scale_features(X_train, X_test):
    """Scale features using RobustScaler."""
    print("\nScaling features...")
    scaler = RobustScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled, X_test_scaled, scaler

def apply_smote(X_train, y_train):
    """Apply SMOTE to handle class imbalance."""
    print("\nApplying SMOTE...")
    smote = SMOTE(random_state=RANDOM_STATE)
    X_resampled, y_resampled = smote.fit_resample(X_train, y_train)
    
    print(f"Before SMOTE - Class distribution: {dict(pd.Series(y_train).value_counts())}")
    print(f"After SMOTE - Class distribution: {dict(pd.Series(y_resampled).value_counts())}")
    
    return X_resampled, y_resampled

def train_models(X_train, y_train):
    """Train multiple classification models."""
    print("\nTraining models...")
    models = {
        'LogisticRegression': LogisticRegression(**CONFIG['models']['LogisticRegression']),
        'DecisionTree': DecisionTreeClassifier(**CONFIG['models']['DecisionTree']),
        'RandomForest': RandomForestClassifier(**CONFIG['models']['RandomForest']),
        'SVM': LinearSVC(**CONFIG['models']['SVM'])
    }
    
    for name, model in models.items():
        print(f"Training {name}...")
        model.fit(X_train, y_train)
    
    return models

def evaluate_models(models, X_test, y_test):
    """Evaluate models and return metrics."""
    print("\nEvaluating models...")
    results = []
    
    for name, model in models.items():
        y_pred = model.predict(X_test)
        
        metrics = {
            'Model': name,
            'Accuracy': accuracy_score(y_test, y_pred),
            'Precision': precision_score(y_test, y_pred, zero_division=0),
            'Recall': recall_score(y_test, y_pred, zero_division=0),
            'F1-Score': f1_score(y_test, y_pred, zero_division=0)
        }
        results.append(metrics)
        
        print(f"\n{name} - Classification Report:")
        print(classification_report(y_test, y_pred, zero_division=0))
        
        # Save confusion matrix for the best model
        if metrics['Accuracy'] == max([r['Accuracy'] for r in results]):
            plot_confusion_matrix(y_test, y_pred, name)
    
    return pd.DataFrame(results)

def plot_confusion_matrix(y_true, y_pred, model_name):
    """Plot and save confusion matrix."""
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Legitimate', 'Fraud'],
                yticklabels=['Legitimate', 'Fraud'])
    plt.title(f'Confusion Matrix - {model_name}')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    
    # Save the figure
    os.makedirs(CONFIG['paths']['figures'], exist_ok=True)
    plt.savefig(os.path.join(CONFIG['paths']['figures'], 'confusion_matrix.png'))
    plt.close()

def save_artifacts(models, metrics_df, scaler):
    """Save models, metrics, and other artifacts."""
    print("\nSaving artifacts...")
    
    # Save the best model
    best_model_name = metrics_df.loc[metrics_df['Accuracy'].idxmax(), 'Model']
    best_model = models[best_model_name]
    
    model_path = os.path.join(CONFIG['paths']['models'], 'best_fraud_model.pkl')
    joblib.dump(best_model, model_path)
    
    # Save the scaler
    scaler_path = os.path.join(CONFIG['paths']['models'], 'robust_scaler.pkl')
    joblib.dump(scaler, scaler_path)
    
    # Save metrics
    metrics_path = os.path.join(CONFIG['paths']['reports'], 'model_metrics.csv')
    metrics_df.to_csv(metrics_path, index=False)
    
    print(f"\nBest model: {best_model_name}")
    print(f"Best accuracy: {metrics_df['Accuracy'].max():.4f}")
    print(f"\nArtifacts saved to {CONFIG['paths']['models']} and {CONFIG['paths']['reports']}")
    
    return best_model_name, model_path

def predict_transaction(transaction_data, model_path=None, scaler_path=None):
    """Predict if a transaction is fraudulent."""
    # Set default paths if not provided
    if model_path is None:
        model_path = os.path.join(CONFIG['paths']['models'], 'best_fraud_model.pkl')
    if scaler_path is None:
        scaler_path = os.path.join(CONFIG['paths']['models'], 'robust_scaler.pkl')
    
    # Load the model and scaler
    try:
        model = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
    except Exception as e:
        print(f"Error loading model or scaler: {str(e)}")
        return None
    
    # Convert to numpy array and reshape
    transaction_array = np.array(transaction_data).reshape(1, -1)
    
    # Scale the features
    scaled_data = scaler.transform(transaction_array)
    
    # Make prediction
    try:
        prediction = model.predict(scaled_data)
        proba = model.predict_proba(scaled_data) if hasattr(model, 'predict_proba') else None
        
        return {
            'is_fraud': bool(prediction[0]),
            'fraud_probability': float(proba[0][1]) if proba is not None else None,
            'model': model.__class__.__name__
        }
    except Exception as e:
        print(f"Error making prediction: {str(e)}")
        return None

def main():
    start_time = datetime.now()
    print(f"\n{'='*50}")
    print(f"Starting Credit Card Fraud Detection")
    print(f"Timestamp: {start_time}")
    print(f"{'='*50}")
    
    try:
        # Setup project structure
        setup_directories()
        
        # 1. Load and preprocess data
        df = load_data(CONFIG['data']['input_file'])
        df = preprocess_data(df)
        
        # 2. Prepare features and target
        X = df.drop(CONFIG['data']['target_column'], axis=1)
        y = df[CONFIG['data']['target_column']]
        
        # 3. Split data
        X_train, X_test, y_train, y_test = split_data(X, y)
        
        # 4. Scale features
        X_train_scaled, X_test_scaled, scaler = scale_features(X_train, X_test)
        
        # 5. Handle class imbalance
        X_resampled, y_resampled = apply_smote(X_train_scaled, y_train)
        
        # 6. Train models
        models = train_models(X_resampled, y_resampled)
        
        # 7. Evaluate models
        metrics_df = evaluate_models(models, X_test_scaled, y_test)
        
        # 8. Save artifacts
        best_model_name, model_path = save_artifacts(models, metrics_df, scaler)
        
        # 9. Demo prediction
        print("\n" + "="*50)
        print("Testing Prediction on Sample Transaction")
        print("="*50)
        
        # Create a sample transaction (using feature means for demo)
        sample_transaction = X_test.sample(1, random_state=RANDOM_STATE).values[0].tolist()
        print(f"\nSample transaction features: {sample_transaction}")
        
        prediction = predict_transaction(sample_transaction)
        if prediction:
            print(f"\nPrediction Result:")
            print(f"- Model: {prediction['model']}")
            print(f"- Is Fraud: {'Yes' if prediction['is_fraud'] else 'No'}")
            if prediction['fraud_probability'] is not None:
                print(f"- Fraud Probability: {prediction['fraud_probability']:.4f}")
        
    except Exception as e:
        print(f"\nError: {str(e)}")
        import traceback
        traceback.print_exc()
    
    end_time = datetime.now()
    print("\n" + "="*50)
    print(f"Completed at {end_time}")
    print(f"Total execution time: {end_time - start_time}")
    print("="*50)

if __name__ == "__main__":
    main()
